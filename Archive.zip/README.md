# alexa-skill-practice

Building a voice calculator for Alexa.

Calculator Intents:

1. Addition
2. Subtraction
3. Multiplication
4. Division

Slots (same for every intent here):

1. First number
2. Second Number

Utterances:

1. "Add two numbers" or "perform addition" or "10 plus 35" or "add 10 and 35"
2. "subtract two numbers" or "perform subtraction" or etc
3. "mulitply two numbers" or etc...
4. "divide two numbers" or etc...

Invoking the skill:

1. "Alexa, open my calculator" or "Alexa, tell my calculator to multiply 2 by 3" or etc...
